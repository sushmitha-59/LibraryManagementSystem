package com.example.minor_project.model;

public enum MyTransactionStatus {
    PENDING,
    SUCCESS,
    FAILURE
}
