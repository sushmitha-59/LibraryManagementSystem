package com.example.minor_project.model;

public enum TransactionType {
    ISSUE,RETURN
}
