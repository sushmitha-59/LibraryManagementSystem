package com.example.minor_project.model;

public enum genre_enum {
    CSE,
    ECE,
    MECH,
    CIVIL,
    PROD,
    BIO
}
